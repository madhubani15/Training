﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Assignment_BoilerPlateCode.DTOs
{
    public class EmployeeProject
    {
        public string EmployeeName { get; set; }
        public string ProjectName { get; set; }
    }
}
